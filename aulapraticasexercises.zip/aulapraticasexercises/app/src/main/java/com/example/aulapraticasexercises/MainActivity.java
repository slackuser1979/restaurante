package com.example.aulapraticasexercises;

import android.annotation.SuppressLint;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import java.text.DecimalFormat;

public class MainActivity extends AppCompatActivity {

    private EditText consumo;
    private EditText couvert;
    private EditText dividirconta;
    private Button calcularconta;
    private EditText taxa;
    private EditText contatotal;
    private EditText valorpessoa;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        contatotal = (EditText) findViewById(R.id.totalconta);
        valorpessoa = (EditText) findViewById(R.id.valorpessoa);
        consumo = (EditText) findViewById(R.id.consumo);
        couvert = (EditText) findViewById(R.id.couvert);
        dividirconta = (EditText) findViewById(R.id.dividirconta);
        calcularconta = (Button) findViewById(R.id.calcularconta);
        taxa = (EditText) findViewById(R.id.taxa);

        calcularconta.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                double consumototal = Double.parseDouble(consumo.getText().toString());
                double couvertartistico = Double.parseDouble(couvert.getText().toString());
                int dividir = Integer.parseInt(dividirconta.getText().toString());
                double servico = ((consumototal + couvertartistico) * 0.10);
                double conta = consumototal + couvertartistico;
                double valor = conta / dividir;
                DecimalFormat df = new DecimalFormat();

                taxa.setText(String.format(df.format(taxa)));
                contatotal.setText(String.format(df.format(contatotal)));
                valorpessoa.setText(String.format(df.format(valorpessoa)));
            }
        });
    }
}